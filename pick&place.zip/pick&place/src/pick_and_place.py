#!/usr/bin/env python3
import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from builtin_interfaces.msg import Duration


class PickAndPlaceNode(Node):
    def __init__(self):
        super().__init__('pick_and_place_node')
        self.arm_client = ActionClient(
            self, FollowJointTrajectory, '/arm_controller/follow_joint_trajectory'
        )
        self.gripper_client = ActionClient(
            self, FollowJointTrajectory, '/gripper_controller/follow_joint_trajectory'
        )
        self.arm_joints = [
            'Revolute_1',
            'Revolute_2',
            'Revolute_3',
            'Revolute_16',
            'Revolute_18'
        ]
        self.gripper_joints = [
            'Revolute_13',
            'Revolute_14',
            'Revolute_15'
        ]

    def send_arm_goal(self, positions, duration_sec=3):
        self.arm_client.wait_for_server()
        goal_msg = FollowJointTrajectory.Goal()
        goal_msg.trajectory.joint_names = self.arm_joints

        point = JointTrajectoryPoint()
        point.positions = [float(p) for p in positions]
        point.time_from_start = Duration(sec=int(duration_sec), nanosec=0)
        goal_msg.trajectory.points.append(point)

        self.get_logger().info(f'Arm Moving -> {positions}')
        future = self.arm_client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, future)
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Arm goal rejected!')
            return False

        res_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, res_future)
        time.sleep(1.0)
        return True

    def send_gripper_goal(self, positions, duration_sec=2):
        self.gripper_client.wait_for_server()
        goal_msg = FollowJointTrajectory.Goal()
        goal_msg.trajectory.joint_names = self.gripper_joints

        point = JointTrajectoryPoint()
        point.positions = [float(p) for p in positions]
        point.time_from_start = Duration(sec=int(duration_sec), nanosec=0)
        goal_msg.trajectory.points.append(point)

        self.get_logger().info(f'Gripper Moving -> {positions}')
        future = self.gripper_client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, future)
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Gripper goal rejected!')
            return False

        res_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, res_future)
        time.sleep(1.0)
        return True

    def execute_sequence(self):
        HOME        = [0.0,  0.0,   0.0,   0.0,   0.0]

        # Green Pedestal (X = 0.170 m, Y = 0.000 m, Ball Z = 0.058 m)
        GREEN_HOVER = [0.0,  0.30,  0.18, -0.48,  0.00]
        GREEN_GRASP = [0.0,  0.34,  0.32, -0.30, -0.36]

        # Blue Pedestal (Base = 1.2 rad -> X = 0.062 m, Y = 0.158 m, Ball Z = 0.058 m)
        BLUE_HOVER  = [1.2,  0.30,  0.18, -0.48,  0.00]
        BLUE_GRASP  = [1.2,  0.34,  0.32, -0.30, -0.36]

        # All 3 claws now share identical axis orientation:
        # Positive opens all 3 claws outward; Negative pinches all 3 claws inward
        GRIPPER_OPEN  = [ 0.38,  0.38,  0.38]
        GRIPPER_CLOSE = [-0.22, -0.22, -0.22]

        self.get_logger().info('=== PHASE 1: GREEN PEDESTAL TO BLUE PEDESTAL ===')
        self.send_arm_goal(HOME, 2)
        self.send_gripper_goal(GRIPPER_OPEN, 2)

        self.send_arm_goal(GREEN_HOVER, 3)
        self.send_arm_goal(GREEN_GRASP, 3)
        self.send_gripper_goal(GRIPPER_CLOSE, 2)
        self.send_arm_goal(GREEN_HOVER, 3)

        self.send_arm_goal(BLUE_HOVER, 3)
        self.send_arm_goal(BLUE_GRASP, 3)
        self.send_gripper_goal(GRIPPER_OPEN, 2)
        self.send_arm_goal(BLUE_HOVER, 3)

        self.get_logger().info('=== PHASE 2: BLUE PEDESTAL TO GREEN PEDESTAL ===')
        self.send_arm_goal(BLUE_GRASP, 3)
        self.send_gripper_goal(GRIPPER_CLOSE, 2)
        self.send_arm_goal(BLUE_HOVER, 3)

        self.send_arm_goal(GREEN_HOVER, 3)
        self.send_arm_goal(GREEN_GRASP, 3)
        self.send_gripper_goal(GRIPPER_OPEN, 2)

        self.send_arm_goal(GREEN_HOVER, 3)
        self.send_arm_goal(HOME, 3)
        self.get_logger().info('=== BIDIRECTIONAL PICK & PLACE COMPLETE! ===')


def main(args=None):
    rclpy.init(args=args)
    node = PickAndPlaceNode()
    node.execute_sequence()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
